import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // ❌ REMOVED: output: "standalone" - was causing Catalyst build errors
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost",
        port: "3000",
        pathname: "/**",
      },
    ],
  },
  experimental: {
    optimizeCss: true,
  },
  // Tell Next.js where to find the app
  distDir: ".next",
};

export default nextConfig;
