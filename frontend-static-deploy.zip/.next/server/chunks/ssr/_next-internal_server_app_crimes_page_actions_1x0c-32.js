module.exports=[13265,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_crimes_page_actions_1x0c-32.js.map