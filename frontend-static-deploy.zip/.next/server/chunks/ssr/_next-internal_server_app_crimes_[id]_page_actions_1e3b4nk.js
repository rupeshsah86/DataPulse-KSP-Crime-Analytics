module.exports=[8714,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_crimes_%5Bid%5D_page_actions_1e3b4nk.js.map