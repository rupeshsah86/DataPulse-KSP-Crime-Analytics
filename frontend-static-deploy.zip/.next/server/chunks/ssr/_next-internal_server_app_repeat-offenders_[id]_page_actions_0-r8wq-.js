module.exports=[61423,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_repeat-offenders_%5Bid%5D_page_actions_0-r8wq-.js.map