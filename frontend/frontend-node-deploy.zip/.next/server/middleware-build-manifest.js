globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/gggOQEo8hVkIoFMPTPVMK/_buildManifest.js",
    "static/gggOQEo8hVkIoFMPTPVMK/_ssgManifest.js",
    "static/gggOQEo8hVkIoFMPTPVMK/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1kbvvjb8xiuz5.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/448lsnj96jqmh.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/turbopack-2z8zm_jsch65a.js"
  ]
};
